package com.tns.frameWork;

public abstract class SavingAcc extends BankAcc {
	private boolean isSalary;
	private static final float MINBAL=1000.0f;                       //blank final variable
	public  void withdraw(float accBal)
	{
		this.accBal=this.accBal-accBal;
		System.out.println(accBal+" : Decucted,Now your Account Balance is :"+this.accBal);
	}
	

	public SavingAcc(int accNo, String accNm, float accBal, boolean isSalary) {
		super(accNo, accNm, accBal);
		this.isSalary = isSalary;
	
	}
	


	public static float getMinbal() {
		return MINBAL;
	}


	@Override
	public String toString() {
		return "SavingAcc [isSalary=" + isSalary + ", accBal=" + accBal + ", getAccNo()=" + getAccNo() + ", getAccNm()="
				+ getAccNm() + ", getAccBal()=" + getAccBal() + ", toString()=" + super.toString() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}


	


	



}
