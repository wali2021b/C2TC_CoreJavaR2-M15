package com.tns.Application;

import com.tns.frameWork.CurrentAcc;

public class MMCurrentAcc  extends CurrentAcc{

	
	
	
	public MMCurrentAcc(int accNo, String accNm, float accBal, float creditLimit) {
		super(accNo, accNm, accBal, creditLimit);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void withdraw(float accBal) {
System.out.println("MM Charges:");
		this.accBal=this.accBal-accBal;
		System.out.println(accBal+" : Decucted,Now your Account Balance is :"+this.accBal);
	}

	
	
	

}
