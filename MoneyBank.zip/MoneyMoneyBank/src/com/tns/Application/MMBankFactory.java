package com.tns.Application;

import com.tns.frameWork.BankAcc;
import com.tns.frameWork.BankFactory;
import com.tns.frameWork.CurrentAcc;
import com.tns.frameWork.SavingAcc;

public class MMBankFactory extends BankFactory{

	@Override
	public SavingAcc getNewSavingAccount(int AccNo, String accNm, float accBal, boolean isSalaried) {
//		MMSavingAcc SavingAcc= (MMSavingAcc) new BankAcc(AccNo, accNm, accBal);
		MMSavingAcc BA=	new MMSavingAcc(AccNo, accNm, accBal, isSalaried);
		return BA;
	}

	@Override
	public CurrentAcc getNewCurrentAccount(int AccNo, String accNm, float accBal, float creditLimit) {
//		MMCurrentAcc mmc=new MMCurrentAcc(AccNo, accNm, creditLimit, creditLimit);
		MMCurrentAcc mmc=new MMCurrentAcc(AccNo, accNm, accBal, creditLimit);
		return mmc;
	}

	


	
	

	

	
}
