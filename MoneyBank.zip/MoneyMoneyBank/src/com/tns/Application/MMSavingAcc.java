package com.tns.Application;

import com.tns.frameWork.*;

public class MMSavingAcc extends SavingAcc{
private static final float 	MINBAL=500.0f;                   //blank final variable




	public MMSavingAcc(int accNo, String accNm, float accBal, boolean isSalary) {
	super(accNo, accNm, accBal, isSalary);
}


	public static float getMinbal() {
	return MINBAL;
}


	@Override
	public void withdraw(float accBal) {
//		System.out.println(accBal+" Amount Debited from the Accoun "+ this.accNm +" Accont NO is : "+this.accNo);
		this.accBal=this.accBal-accBal;
		System.out.println(accBal+" : Decucted,Now your Account Balance is :"+this.accBal);
//  System.out.println("Dear Customer Your Account Balance is: "+accBal);		
	}


	

	

}
