package com.tns.client;

import com.tns.Application.MMBankFactory;
import com.tns.Application.MMCurrentAcc;
import com.tns.Application.MMSavingAcc;
import com.tns.frameWork.BankAcc;
import com.tns.frameWork.BankFactory;
import com.tns.frameWork.CurrentAcc;
import com.tns.frameWork.SavingAcc;

public class Client {

	public static void main(String[] args) {
	System.out.println("Sayyed Waliullah M-15 \n Id:CAP20111221\n\n");
		
		
		BankFactory bf= new MMBankFactory();

		SavingAcc sa=new MMSavingAcc(101, "Aman", 3000, true);
		System.out.println("Savaing Accunt Info...\n");

//		System.out.println(sa);                  // toString methods invokes and runs..
//	String name=sa.getAccNm();
//	System.out.println(name);
//		sa.deposite(450);
		sa.toString();
		sa.withdraw(1000);
		
		CurrentAcc ca	=new MMCurrentAcc(201, "zaid", 5000, 999999.0f);
		System.out.println("\n\nCurrent  Accunt Info...\n");
//		ca.withdraw(222.37);
		ca.withdraw(300.5f);
		ca.toString();
//		ca.deposite(400);
//	 System.out.println(ca);
	
		
	}

}
