package com.tns.client;

public interface Bike {
String color="blue";
void model();
void run(int speed);
}
